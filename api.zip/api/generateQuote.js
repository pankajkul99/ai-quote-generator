export default async function handler(req, res) {
  const { keywords, language } = req.body;

  const prompt = `Generate a short, emotional quote in ${language} based on the keywords: ${keywords}.`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer 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",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a quote writer who writes emotional, short quotes." },
          { role: "user", content: prompt }
        ],
        temperature: 0.9
      })
    });

    const data = await response.json();
    const aiQuote = data.choices?.[0]?.message?.content;
    res.status(200).json({ quote: aiQuote });
  } catch (error) {
    res.status(500).json({ error: "Failed to generate quote" });
  }
}
